module.exports = function() {
    // 输入你的配置
    return {
        appId: 'wx093bb0b5415e677c',
        appSecret: '718670129ed0609cdd1c72d0057d3ea0',
        appToken: 'qphall',
    };
};