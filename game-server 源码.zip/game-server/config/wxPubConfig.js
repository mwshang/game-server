module.exports = function() {
    // 输入你的配置
    return {
        appId: 'wxbf1ca4494370738c',
        appSecret: '0c38848206a7bfb0e83d7adff1b5ccff',
        appToken: 'qphall',
        cache_json_file: '.'
    };
};