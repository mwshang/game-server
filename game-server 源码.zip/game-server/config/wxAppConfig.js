module.exports = function() {
    // 输入你的配置
    return {
        appId: 'wxf491c307a8e3f599',
        appSecret: 'b88d8263520b8cf051c6a8804f4e26cd',
        appToken: 'qphall'
    };
};
